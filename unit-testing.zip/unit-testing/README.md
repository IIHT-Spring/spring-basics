# Unit testing examples

Tutorials related to this project:

1. [Spring rest controller unit test example](https://howtodoinjava.com/spring-boot2/rest-controller-unit-test-example/).
2. [Junit 5 with Spring boot 2](https://howtodoinjava.com/spring-boot2/junit5-with-spring-boot2/)
3. [Spring boot integration test example](https://howtodoinjava.com/spring-boot2/spring-integration-testing/)

## Import the project into Eclipse IDE

If you want to import these project into the local eclipse setup - 

1. Download the project as zip file into your computer
2. Unzip the project at your desired location
3. Import the project into Eclipse as existing maven project

```
File > Import... > Maven > Existing Maven Projects
```