package com.rest.service;

import com.rest.model.Employee;
import com.rest.model.Employees;

public interface IEmployeeService {

	Employees getEmployees();

	Employee save(Employee employee);

}
