package com.rest.service;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.rest.dao.EmployeeRepository;
import com.rest.model.Employee;
import com.rest.model.Employees;

@Service
public class EmployeeService implements IEmployeeService {
	@Autowired
	private EmployeeRepository employeeRepository;

	@Override
	public Employees getEmployees() {
		Employees response = new Employees();
		ArrayList<Employee> list = new ArrayList<>();
		employeeRepository.findAll().forEach(e -> list.add(e));
		response.setEmployeeList(list);
		return response;
	}

	@Override
	public Employee save(Employee employee) {
		return employeeRepository.save(employee);
	}
}
